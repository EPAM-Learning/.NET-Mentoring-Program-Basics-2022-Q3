﻿using ConcatenationLogic2;
using System;

namespace NET_FundamentalsTask2
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Please enter username: ");
                Concatenation concatenation = new Concatenation();
                Console.WriteLine(concatenation.GetValue(Console.ReadLine()));
                Console.ReadKey();
            }
            catch (Exception)
            {

                throw;
            }
            
        }
    }
}
