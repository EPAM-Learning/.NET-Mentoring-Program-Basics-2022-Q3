﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConcatenationLogic2
{
    public class Concatenation
    {
        public string GetValue(string username)
        {
            return ($"{DateTime.Now} Hello , {username} !");
        }
    }
}
