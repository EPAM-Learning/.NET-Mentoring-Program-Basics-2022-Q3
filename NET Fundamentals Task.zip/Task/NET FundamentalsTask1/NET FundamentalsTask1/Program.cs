﻿using System;

namespace NET_FundamentalsTask1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Please enter username: ");
                Console.WriteLine($"Hello {Console.ReadLine()}");
                Console.ReadKey();
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
